import mysql.connector

def conectar():
    conexion = mysql.connector.connect(
        host="localhost",
        user="root",
        password="@Luiferpt12.",
        database="cgc"
)

    return conexion